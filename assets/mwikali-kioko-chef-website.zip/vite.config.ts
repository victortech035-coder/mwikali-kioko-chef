import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          about: path.resolve(__dirname, 'about.html'),
          menu: path.resolve(__dirname, 'menu.html'),
          gallery: path.resolve(__dirname, 'gallery.html'),
          services: path.resolve(__dirname, 'services.html'),
          bookings: path.resolve(__dirname, 'bookings.html'),
          contact: path.resolve(__dirname, 'contact.html'),
          admin: path.resolve(__dirname, 'admin/index.html'),
          adminDashboard: path.resolve(__dirname, 'admin/dashboard.html'),
          adminMenu: path.resolve(__dirname, 'admin/menu.html'),
          adminOrders: path.resolve(__dirname, 'admin/orders.html'),
          adminBookings: path.resolve(__dirname, 'admin/bookings.html'),
          adminGallery: path.resolve(__dirname, 'admin/gallery.html'),
        },
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
