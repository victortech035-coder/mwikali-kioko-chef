/**
 * Netlify Serverless Function Wrapper for Mwikali Kioko Backend
 */

exports.handler = async (event, context) => {
  const path = event.path.replace(/\.netlify\/functions\/api\/?/, '');
  const method = event.httpMethod;

  // Simple CORS response
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (method === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      message: 'Mwikali Kioko Netlify API gateway operational.',
      endpoint: path
    })
  };
};
