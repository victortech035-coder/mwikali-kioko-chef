/**
 * Food Gallery & Lightbox Viewer
 */

const GalleryPage = {
  currentCategory: 'All',
  items: [],
  currentIndex: 0,

  async init() {
    this.attachEventListeners();
    await this.fetchAndRender();
  },

  attachEventListeners() {
    const filterButtons = document.querySelectorAll('.gallery-filter-btn');
    filterButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        filterButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.currentCategory = btn.dataset.category || 'All';
        this.renderGallery();
      });
    });

    // Close lightbox on escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeLightbox();
      if (e.key === 'ArrowRight') this.nextImage();
      if (e.key === 'ArrowLeft') this.prevImage();
    });
  },

  async fetchAndRender() {
    try {
      this.items = await window.SupabaseBridge.getGallery();
      this.renderGallery();
    } catch (e) {
      console.error('Failed to load gallery items', e);
    }
  },

  renderGallery() {
    const grid = document.getElementById('gallery-grid');
    if (!grid) return;

    let filtered = this.items;
    if (this.currentCategory !== 'All') {
      filtered = this.items.filter(i => i.category === this.currentCategory);
    }

    if (filtered.length === 0) {
      grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--color-muted);">No images found for this category.</p>';
      return;
    }

    grid.innerHTML = filtered.map((item, idx) => `
      <div class="gallery-item" onclick="GalleryPage.openLightbox(${idx})" tabindex="0" role="button" aria-label="${item.title}">
        <img src="${item.image_url}" alt="${item.title}" loading="lazy">
        <div class="gallery-item-overlay">
          <span class="gallery-item-category">${item.category}</span>
          <h4 class="gallery-item-title">${item.title}</h4>
        </div>
      </div>
    `).join('');
  },

  openLightbox(index) {
    let filtered = this.items;
    if (this.currentCategory !== 'All') {
      filtered = this.items.filter(i => i.category === this.currentCategory);
    }

    const item = filtered[index];
    if (!item) return;

    this.currentIndex = index;
    const modal = document.getElementById('gallery-lightbox');
    const img = document.getElementById('lightbox-image');
    const title = document.getElementById('lightbox-title');
    const caption = document.getElementById('lightbox-caption-text');

    if (modal && img && title) {
      img.src = item.image_url;
      img.alt = item.title;
      title.textContent = item.title;
      if (caption) caption.textContent = item.caption || '';

      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  },

  closeLightbox() {
    const modal = document.getElementById('gallery-lightbox');
    if (modal) {
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }
  },

  nextImage() {
    let filtered = this.items;
    if (this.currentCategory !== 'All') {
      filtered = this.items.filter(i => i.category === this.currentCategory);
    }
    if (filtered.length === 0) return;
    this.openLightbox((this.currentIndex + 1) % filtered.length);
  },

  prevImage() {
    let filtered = this.items;
    if (this.currentCategory !== 'All') {
      filtered = this.items.filter(i => i.category === this.currentCategory);
    }
    if (filtered.length === 0) return;
    this.openLightbox((this.currentIndex - 1 + filtered.length) % filtered.length);
  }
};

window.GalleryPage = GalleryPage;
document.addEventListener('DOMContentLoaded', () => GalleryPage.init());
