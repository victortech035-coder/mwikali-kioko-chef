-- =============================================================================
-- MWIKALI KIOKO - CHEF & CATERING
-- Seed Data for Supabase Database
-- =============================================================================

INSERT INTO site_settings (business_name, brand_tagline, brand_subtitle, whatsapp_number, phone, email, service_location, business_hours, currency)
VALUES (
  'Mwikali Kioko',
  'Every Dish Tells a Story',
  'Beautifully prepared meals, exceptional flavours, and memorable catering experiences.',
  '+254712345678',
  '+254 712 345 678',
  'enquiries@mwikalikioko.co.ke',
  'Nairobi, Kenya',
  'Monday - Saturday: 08:00 AM - 08:00 PM',
  'KSh'
);

INSERT INTO menu_items (name, category, price, description, image_url, is_available, dietary, featured, spiciness) VALUES
(
  'Swahili Beef Pilau Ya Sherehe',
  'Rice & Pilau',
  950.00,
  'Fragrant basmati rice infused with whole cardamom, cinnamon, cloves, cumin, and tender slow-simmered beef shank. Served with fresh kachumbari.',
  '/assets/images/kenyan_beef_pilau.jpg',
  true,
  ARRAY['Halal', 'Dairy-Free'],
  true,
  'Mildly Spiced'
),
(
  'Flame-Kissed Nyama Choma Platter',
  'Traditional Kenyan',
  1850.00,
  'Tender goat and prime beef cuts marinated in sea salt, rosemary, garlic and charred over wood coals. Accompanied by steaming ugali, roasted chili salsa, and kachumbari.',
  '/assets/images/nyama_choma_platter.jpg',
  true,
  ARRAY['Gluten-Free Option', 'Halal'],
  true,
  'Chef''s Blend'
),
(
  'Coconut Kuku Paka (Coastal Chicken Curry)',
  'Main Dishes',
  1250.00,
  'Char-grilled free-range chicken simmered in rich spiced coconut cream with turmeric, lemongrass, and fresh coriander. Served with fragrant saffron rice or chapati.',
  '/assets/images/hero_chef_plating.jpg',
  true,
  ARRAY['Halal', 'Gluten-Free'],
  true,
  'Medium'
),
(
  'Artisanal Beef & Veg Samosa Trio',
  'Snacks & Appetisers',
  450.00,
  'Golden crispy pastry triangles stuffed with spiced minced beef, spring onions, and coriander. Served with tamarind dip and lime wedges.',
  '/assets/images/kenyan_beef_pilau.jpg',
  true,
  ARRAY['Halal'],
  false,
  'Mild'
),
(
  'Tilapia wa Nazi (Lake Victoria Coconut Fish)',
  'Main Dishes',
  1600.00,
  'Whole fresh Lake Victoria Tilapia pan-seared and braised in rich tomato-coconut sauce with bell peppers, green chilies, and fresh dhania.',
  '/assets/images/hero_chef_plating.jpg',
  true,
  ARRAY['Pescatarian', 'Gluten-Free'],
  false,
  'Medium'
),
(
  'Traditional Mukimo wa Nyama',
  'Traditional Kenyan',
  1100.00,
  'Homestyle mashed potatoes, fresh pumpkin leaves (kahurura), sweet corn and peas folded with braised prime beef cubes in rich natural gravy.',
  '/assets/images/nyama_choma_platter.jpg',
  true,
  ARRAY['Comfort Classic'],
  false,
  'Mild'
),
(
  'Coastal Mahamri & Cardamom Custard',
  'Desserts',
  500.00,
  'Fluffy triangle donuts infused with freshly ground cardamom and coconut milk, dusted with icing sugar and served with warm vanilla-coconut custard.',
  '/assets/images/hero_chef_plating.jpg',
  true,
  ARRAY['Vegetarian'],
  false,
  'Sweet'
),
(
  'Fresh Hibiscus-Ginger Dawa Cooler (500ml)',
  'Drinks',
  350.00,
  'Cold-pressed hibiscus flowers steeped with organic ginger root, fresh lime juice, and raw acacia honey.',
  '/assets/images/luxury_catering_setup.jpg',
  true,
  ARRAY['Vegan', 'Organic', 'Caffeine-Free'],
  false,
  'Refreshing Zest'
);

INSERT INTO services (title, short_description, image_url, guest_capacity, features) VALUES
(
  'Weddings & Reception Catering',
  'Exquisite culinary styling, bespoke multi-course menus, and attentive silver-service staff for your dream celebration.',
  '/assets/images/luxury_catering_setup.jpg',
  '50 - 1,000+ Guests',
  ARRAY[
    'Custom wedding menu tasting session',
    'Full buffet or formal plated service',
    'Professional waitstaff & beverage coordination',
    'High-grade chafing sets & luxury presentation'
  ]
),
(
  'Corporate Conferences & Gala Dinners',
  'Punctual, seamless culinary execution for executive summits, brand launches, annual dinners, and cocktail networking events.',
  '/assets/images/hero_chef_plating.jpg',
  '20 - 500+ Guests',
  ARRAY[
    'Executive breakfast, lunch & coffee break spreads',
    'Finger-food cocktail canapés',
    'Prompt invoice & corporate payment support',
    'Strict dietary labeling (Halal, Vegan, Gluten-Free)'
  ]
),
(
  'Private In-Home Chef Experience',
  'Chef Mwikali cooks exclusively in your kitchen or residence for intimate anniversaries, VIP dinners, and milestones.',
  '/assets/images/chef_mwikali_portrait.jpg',
  '2 - 25 Guests',
  ARRAY[
    'Personalised 3 to 5-course tailored menu',
    'Fresh premium ingredient sourcing by Chef Mwikali',
    'Wine or beverage pairing recommendations',
    'Complete post-service kitchen clean-up'
  ]
),
(
  'Birthdays & Family Celebrations',
  'Lively, delicious feasts including live nyama choma grilling stations, pilau bars, and celebratory grazing tables.',
  '/assets/images/nyama_choma_platter.jpg',
  '15 - 200 Guests',
  ARRAY[
    'On-site charcoal grill station option',
    'Kid-friendly and adult gourmet menus',
    'Custom desserts & beverage station',
    'Flexible setup suited for private residences or gardens'
  ]
);

INSERT INTO gallery_images (title, category, image_url, caption, display_order) VALUES
(
  'Chef Mwikali Plating Afro-Fusion Course',
  'Chef at Work',
  '/assets/images/hero_chef_plating.jpg',
  'Mwikali putting the final floral touch on a pan-seared entrée in Nairobi.',
  1
),
(
  'Swahili Festive Pilau & Fresh Kachumbari',
  'Cuisine',
  '/assets/images/kenyan_beef_pilau.jpg',
  'Slow-steamed spiced basmati pilau with caramelised onions and diced heirloom tomatoes.',
  2
),
(
  'Charcoal Flame Grilled Nyama Choma Platter',
  'Cuisine',
  '/assets/images/nyama_choma_platter.jpg',
  'Open-fire roast goat meat seasoned with Kenyan coastal sea salt, ugali, and charred chilies.',
  3
),
(
  'Luxury Karen Garden Wedding Catering',
  'Events',
  '/assets/images/luxury_catering_setup.jpg',
  'Full banquet service setup with elegant forest green and gold presentation for 250 guests.',
  4
),
(
  'Chef Mwikali Kioko - Executive Culinary Director',
  'Chef at Work',
  '/assets/images/chef_mwikali_portrait.jpg',
  'Leading the kitchen with passion, culinary discipline, and deep respect for African gastronomy.',
  5
);
