-- =============================================================================
-- MWIKALI KIOKO - CHEF & CATERING
-- PostgreSQL Database Schema for Supabase
-- =============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Site Settings Table
CREATE TABLE IF NOT EXISTS site_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_name TEXT NOT NULL DEFAULT 'Mwikali Kioko',
  brand_tagline TEXT NOT NULL DEFAULT 'Every Dish Tells a Story',
  brand_subtitle TEXT NOT NULL DEFAULT 'Beautifully prepared meals, exceptional flavours, and memorable catering experiences.',
  whatsapp_number TEXT NOT NULL DEFAULT '+254712345678',
  phone TEXT NOT NULL DEFAULT '+254 712 345 678',
  email TEXT NOT NULL DEFAULT 'enquiries@mwikalikioko.co.ke',
  service_location TEXT NOT NULL DEFAULT 'Nairobi, Kenya',
  business_hours TEXT NOT NULL DEFAULT 'Monday - Saturday: 08:00 AM - 08:00 PM',
  currency TEXT NOT NULL DEFAULT 'KSh',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. Menu Items Table
CREATE TABLE IF NOT EXISTS menu_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
  description TEXT NOT NULL,
  image_url TEXT NOT NULL,
  is_available BOOLEAN NOT NULL DEFAULT true,
  dietary TEXT[] DEFAULT '{}',
  featured BOOLEAN NOT NULL DEFAULT false,
  spiciness TEXT DEFAULT 'Mild',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_menu_items_category ON menu_items(category);
CREATE INDEX IF NOT EXISTS idx_menu_items_available ON menu_items(is_available);

-- 3. Catering Services Table
CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  short_description TEXT NOT NULL,
  image_url TEXT NOT NULL,
  guest_capacity TEXT NOT NULL,
  features TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 4. Gallery Images Table
CREATE TABLE IF NOT EXISTS gallery_images (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  image_url TEXT NOT NULL,
  caption TEXT,
  display_order INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_gallery_category ON gallery_images(category);

-- 5. Customer Orders Table
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  delivery_type TEXT NOT NULL CHECK (delivery_type IN ('delivery', 'collection')),
  delivery_address TEXT,
  preferred_date DATE NOT NULL,
  preferred_time TEXT NOT NULL,
  subtotal NUMERIC(10, 2) NOT NULL CHECK (subtotal >= 0),
  delivery_fee NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (delivery_fee >= 0),
  total_amount NUMERIC(10, 2) NOT NULL CHECK (total_amount >= 0),
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN (
    'Pending', 'Accepted', 'Preparing', 'Ready for collection', 'Out for delivery', 'Completed', 'Cancelled'
  )),
  payment_status TEXT NOT NULL DEFAULT 'Pending Arrangement',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);

-- 6. Order Line Items Table
CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  menu_item_id UUID REFERENCES menu_items(id) ON DELETE SET NULL,
  dish_name TEXT NOT NULL,
  unit_price NUMERIC(10, 2) NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  subtotal NUMERIC(10, 2) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- 7. Catering Bookings / Enquiries Table
CREATE TABLE IF NOT EXISTS catering_bookings (
  id TEXT PRIMARY KEY,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  event_type TEXT NOT NULL,
  event_date DATE NOT NULL,
  location TEXT NOT NULL,
  guest_count INT NOT NULL CHECK (guest_count >= 2),
  preferred_service TEXT,
  budget_range TEXT,
  additional_requirements TEXT,
  status TEXT NOT NULL DEFAULT 'New' CHECK (status IN (
    'New', 'Contacted', 'Quote Sent', 'Confirmed', 'Completed', 'Declined'
  )),
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_catering_bookings_date ON catering_bookings(event_date);
CREATE INDEX IF NOT EXISTS idx_catering_bookings_status ON catering_bookings(status);
