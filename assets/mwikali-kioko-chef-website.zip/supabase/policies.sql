-- =============================================================================
-- MWIKALI KIOKO - CHEF & CATERING
-- Supabase Row Level Security (RLS) Policies
-- =============================================================================

-- Enable RLS on all tables
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE catering_bookings ENABLE ROW LEVEL SECURITY;

-- -----------------------------------------------------------------------------
-- 1. Public Read Policies
-- -----------------------------------------------------------------------------

-- Public can view site settings
CREATE POLICY "Public can view site settings"
  ON site_settings FOR SELECT
  TO anon, authenticated
  USING (true);

-- Public can view published menu items
CREATE POLICY "Public can view active menu items"
  ON menu_items FOR SELECT
  TO anon, authenticated
  USING (true);

-- Public can view catering services
CREATE POLICY "Public can view services"
  ON services FOR SELECT
  TO anon, authenticated
  USING (true);

-- Public can view gallery images
CREATE POLICY "Public can view gallery"
  ON gallery_images FOR SELECT
  TO anon, authenticated
  USING (true);

-- -----------------------------------------------------------------------------
-- 2. Public Submission Policies (Carefully Scoped Insert Only)
-- -----------------------------------------------------------------------------

-- Public can submit customer orders
CREATE POLICY "Public can insert orders"
  ON orders FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    customer_name IS NOT NULL AND
    customer_phone IS NOT NULL AND
    status = 'Pending' AND
    subtotal >= 0 AND
    total_amount >= subtotal
  );

-- Public can insert order line items corresponding to their submitted order
CREATE POLICY "Public can insert order items"
  ON order_items FOR INSERT
  TO anon, authenticated
  WITH CHECK (quantity > 0 AND unit_price >= 0);

-- Public can submit catering enquiries
CREATE POLICY "Public can submit catering bookings"
  ON catering_bookings FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    customer_name IS NOT NULL AND
    customer_phone IS NOT NULL AND
    event_date >= CURRENT_DATE AND
    guest_count >= 2 AND
    status = 'New'
  );

-- -----------------------------------------------------------------------------
-- 3. Administrator Elevated Policies (Full Access for Authenticated Admins)
-- -----------------------------------------------------------------------------

-- Admins can update site settings
CREATE POLICY "Admins full access to site_settings"
  ON site_settings FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Admins can manage menu items (insert, update, delete)
CREATE POLICY "Admins full access to menu_items"
  ON menu_items FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Admins can manage services
CREATE POLICY "Admins full access to services"
  ON services FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Admins can manage gallery images
CREATE POLICY "Admins full access to gallery"
  ON gallery_images FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Admins can view and update all orders
CREATE POLICY "Admins full access to orders"
  ON orders FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Admins can view order line items
CREATE POLICY "Admins full access to order_items"
  ON order_items FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Admins can view and update catering bookings
CREATE POLICY "Admins full access to catering_bookings"
  ON catering_bookings FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);
